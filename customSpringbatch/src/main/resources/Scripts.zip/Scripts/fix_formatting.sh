#!/bin/bash

# Input file (replace 'input.txt' with your actual file)
input_file="input.txt"

# Read the file into an array
mapfile -t lines < "$input_file"

# Get the total number of lines
total_lines=${#lines[@]}

# Process the last line
if [[ $total_lines -gt 0 ]]; then
    last_line="${lines[$((total_lines-1))]}"
    
    # Find the positions of all '|' characters
    pipe_positions=$(echo "$last_line" | grep -b -o '|' | cut -d: -f1)
    
    # Convert the positions into an array
    pipe_positions_array=($pipe_positions)
    
    # Check if there are at least two '|' characters
    if [[ ${#pipe_positions_array[@]} -ge 2 ]]; then
        # Get the position of the second last '|'
        second_last_pipe_position=${pipe_positions_array[-2]}
        
        # Extract the part before the second last '|' and remove one trailing space
        before_pipe="${last_line:0:$second_last_pipe_position}"
        before_pipe=$(echo "$before_pipe" | sed 's/ *$//')  # Remove trailing spaces
        before_pipe="${before_pipe% }"  # Remove one additional space
        
        # Extract the part after the second last '|'
        after_pipe="${last_line:$second_last_pipe_position}"
        
        # Reconstruct the last line
        last_line="${before_pipe}|${after_pipe}"
        lines[$((total_lines-1))]="$last_line"
    fi
fi

# Output the modified lines
for line in "${lines[@]}"; do
    echo "$line"
done