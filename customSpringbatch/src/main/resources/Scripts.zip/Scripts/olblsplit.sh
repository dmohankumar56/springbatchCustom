#!/bin/bash

# Check if the correct number of arguments is provided
if [ "$#" -ne 2 ]; then
  echo "Usage: $0 <file_name> <split_size>"
  exit 1
fi

# Parameters
FILE_NAME=$1
SPLIT_SIZE=$2

# Print the action
echo "Splitting file: $FILE_NAME with size: $SPLIT_SIZE KB"

# Simulate the split operation
echo "Split operation is happening... (This is a placeholder)"

# Success message
echo "Split completed for file: $FILE_NAME"
