#!/bin/bash

# Call the original script and capture its output
OUTPUT=$(./olblsplit.sh file.txt 1024)

# Extract the FILE_ID from the output
FILE_ID=$(echo "$OUTPUT" | grep -oP 'FILE_ID=\K.*' | tail -1)


# Print the FILE_ID
echo "Received FILE_ID: $FILE_ID"
