#!/bin/bash

# Directories
OUTBOX_DIR="D:/Scripts/outbox"
INBOX_DIR="D:/Scripts/inbox"

# Ensure the inbox directory exists
if [ ! -d "$INBOX_DIR" ]; then
  echo "Inbox directory does not exist. Creating it at: $INBOX_DIR"
  mkdir -p "$INBOX_DIR"
fi

# Loop through each folder in the outbox directory
for folder in "$OUTBOX_DIR"/*/; do
  # Check if it's a directory
  if [ -d "$folder" ]; then
    echo "Processing folder: $folder"
    
    # Move all files in the folder to the inbox directory
    for file in "$folder"*; do
      if [ -f "$file" ]; then
        echo "Moving file: $file to $INBOX_DIR"
        mv "$file" "$INBOX_DIR/"
      fi
    done
  fi
done

echo "All files have been moved to the inbox directory."
