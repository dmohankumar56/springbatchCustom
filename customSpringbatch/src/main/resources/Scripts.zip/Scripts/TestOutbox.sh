#!/bin/bash

# Define the outbox folder and the script to call
OUTBOX_FOLDER="D:/Scripts/outbox"
SCRIPT_TO_CALL="D:/Scripts/olblsplit.sh"
SPLIT_SIZE=100  # Set the default split size (in KB, or change as needed)

# Check if the outbox folder exists
if [ ! -d "$OUTBOX_FOLDER" ]; then
  echo "Outbox folder does not exist: $OUTBOX_FOLDER"
  exit 1
fi

# Loop through all files in the outbox folder
for file in "$OUTBOX_FOLDER"/*; do
  # Check if the file exists (to avoid issues if the folder is empty)
  if [ -f "$file" ]; then
    echo "Processing file: $file with split size: $SPLIT_SIZE"
    # Call the script with the file name and split size as parameters
    bash "$SCRIPT_TO_CALL" "$file" "$SPLIT_SIZE"
    if [ $? -ne 0 ]; then
      echo "Error processing file: $file"
    else
      echo "Successfully processed: $file"
    fi
  fi
done

echo "Processing completed."
